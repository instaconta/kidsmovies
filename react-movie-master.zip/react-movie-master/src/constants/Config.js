export const HOME_PAGE = "react-movie-app";
